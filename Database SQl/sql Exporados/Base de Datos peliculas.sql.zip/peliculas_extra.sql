
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `peliculas`
--
ALTER TABLE `peliculas`
  ADD CONSTRAINT `fk_actores_pelicula` FOREIGN KEY (`actor_id`) REFERENCES `actores` (`id`),
  ADD CONSTRAINT `fk_director_pelicula` FOREIGN KEY (`director_id`) REFERENCES `directores` (`id`);
